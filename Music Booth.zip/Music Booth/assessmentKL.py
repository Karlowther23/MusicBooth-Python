#Name - Karl Lowther
#Student Number - R00154691

#variables
maxMembers = 8
musician1 = ""
musician2 = ""
musician3 = ""
musician4 = ""
musician5 = ""
musician6 = ""
musician7 = ""
musician8 = ""
instrument1 = ""
instrument2 = ""
instrument3 = ""
instrument4 = ""
instrument5 = ""
instrument6 = ""
instrument7 = ""
instrument8 = ""


#code to ask for name
name = input('Please Enter Your first Name')
print(name)
while name == "":
    print('Thats empty try again')
    name = input('What is your first name')

while name != "":
    if name.isalpha():
        break
    else:
        print("Please input name")
        name = input('What is your first name')
        print(name)

print()

Sname = input('Please Enter Your surname')
print(Sname)
while Sname == "":
    print("That's empty try again")
    name = input('What is your surname')

while Sname != "":
    if Sname.isalpha():
        break
    else:
        print("Please input name")
        Sname = input('What is your surname')
        print(Sname)

print()
#code to ask for band name
bandname = input('Please Enter the band Name')
print(bandname)
while bandname == "":
    print('Thats empty try again')
    bandname = input('What is band name')

while bandname == "":
    if bandname.isalnum():
        break
    else:
        print("Please input name")
        bandname = input('What is the band name')
        print(bandname)

print()
#code to ask for email
email = input('What is your email address?')
print(email)
while email == "":
    email = input('What is your email')

print()
#code to ask for phone number
num = input('What is your phone number(10 didgets, no spaces)')
while num.__len__() != 10:
    num = input('What is your phone number(10 didgets, no spaces)')
print(num)
while num == "":
    num = input('What is your phone number')
while num != "":
    if num.isnumeric():
        break
    else:
        print("Please input number")
        num = input('What is your phone number')
        print(num)

print()
#code asking for start date
print('What Date are you looking for?(dd/mm/yyyy)')
day = input('Enter day(dd)')
while day.__len__() != 2:
    day = input('Enter day(dd)')
month = input('Enter month(mm)')
while month.__len__() != 2:
    month = input('Enter month(mm)')
year = input('Enter year(yyyy)')
while year.__len__() != 4:
    year = input('Enter year(yyyy)')
print(day, '/', month,  '/', year)

#code asking for how many members
print()
members = int(input('How many band members'))
print(members)

while members <= 0:
    print('number too small')
    members = int(input('How many band members'))
    break

while members > maxMembers:
    print('number too big')
    members = int(input('How many band members'))
    break

print('')
#coe askig for musicians and instruments
if members >= 1:
    musician1 = input('Name1:')
    instrument1 = input('Instrument1:')

    print(musician1, ' ', instrument1)


if members >= 2:
    musician2 = input('Name2:')
    instrument2 = input('Instrument2:')
    print(musician2, ' ', instrument2)

if members >= 3:
    musician3 = input('Name3:')
    instrument3 = input('Instrument3:')
    print(musician3, ' ', instrument3)

if members >= 4:
    musician4= input('Name4:')
    instrument4 = input('Instrument4:')
    print(musician4, ' ', instrument4)

if members >= 5:
    musician5 = input('Name5:')
    instrument5 = input('Instrument5:')
    print(musician5, ' ', instrument5)

if members >= 6:
    musician6 = input('Name6:')
    instrument6 = input('Instrument6:')
    print(musician6, ' ', instrument6)

if members >= 7:
    musician7 = input('Name7:')
    instrument7 = input('Instrument7:')
    print(musician7, ' ', instrument7)

if members >= 8:
    musician8 = input('Name8:')
    instrument8 = input('Instrument8:')
    print(musician8, ' ', instrument8)

print()
print('There are 8 free sessions in the studio.')
#code showing spaces left
if members == 1:
    print('With 1 band member, there are 7 spaces left.')

elif members == 2:
    print('With 2 band members, there are 6 spaces left.')

elif members == 3:
    print('With 3 band members, there are 5 spaces left.')

elif members == 4:
    print('With 4 band members, there are 4 spaces left.')

elif members == 5:
    print('With 5 band members, there are 3 spaces left.')

elif members == 6:
    print('With 6 band members, there are 2 spaces left.')

elif members == 7:
    print('With 7 band members, there are 1 spaces left.')

elif members == 8:
    print('With 8 band members, there are 0 spaces left.')
else:
    print('Error')

print()
#code asking how long user will stay
print('Please enter number of days below')
print()
print('For 1 day , pay €260')
print('For 2-4 days, pay €240 per day')
print('For 5-8 days, pay €210 per day')
print('For 9 days or more, pay €200 per day')
length = int(input())
while length <=0:
    print('Error, try again')
    length = int(input())

print()
cost1 = length * 260
cost2 = length * 240
cost3 = length * 210
cost4 = length * 200

print()

print('You have booked for ',length, 'day(s)')

print()
#code askig for how user is going to pay
print('How will you pay by?')
print('Enter 1 for Credit Card(5% levy)')
print('Enter 2 for Cash(5% discount)')
print('Enter 3 for Cheque')
pay = int(input())

while pay <=0 or pay > 3:
    print('Error, try again')
    pay = int(input())

#code showing different ways of calculating input
if pay == 1:
    print('Credit card')
    creditLevy = cost1 * 0.05
    cost1 = cost1 + creditLevy

    creditLevy2 = cost2 * 0.05
    cost2 = cost2 + creditLevy2

    creditLevy3 = cost3 * 0.05
    cost3 = cost3 + creditLevy3

    creditLevy4 = cost4 * 0.05
    cost4 = cost4 + creditLevy4
elif pay == 2:
    print('Cash')
    cashDiscount = cost1 * 0.05
    cost1 = cost1 - cashDiscount

    cashDiscount2 = cost2 * 0.05
    cost2 = cost2 - cashDiscount2

    cashDiscount3 = cost3 * 0.05
    cost3 = cost3 - cashDiscount3

    cashDiscount4 = cost4 * 0.05
    cost4 = cost4 - cashDiscount4
elif pay == 3:
    print('Cheque')
else:
    while pay <0 or pay > 3:
        print('Error, try again')
        pay = int(input())

print()

#code shwoing full price
if length == 1:
    print('Price will be €',cost1)
elif length >= 2 and length <= 4:
    print('Price will be €',cost2)
elif length >= 5 and length <= 8:
    print('Price will be €',cost3)
elif length >= 9:
    print('Price will be €', cost4)
else:
    print('Error')

print()
#code for the booking application
print('Would you Like to book?')
press = (input('Type BOOK or CANCEL'))
print()
if press == 'BOOK':
    print('Booking Application')
    print('-----------------------------------')
    print('Requisition by: ', name, ' Contact: ', 'Email-', email, '&','Tel-',num)
    print()
    print('Band name is:', bandname)
    print()
    print('Date requested --->', day, '/', month, '/', year)
    print()
    print('Band Members')
    print('-------------------------------')
    print('1:', musician1, '-', instrument1)
    print('2:', musician2, '-', instrument2)
    print('3:', musician3, '-', instrument3)
    print('4:', musician4, '-', instrument4)
    print('5:', musician5, '-', instrument5)
    print('6:', musician6, '-', instrument6)
    print('7:', musician7, '-', instrument7)
    print('8:', musician8, '-', instrument8)
    print()
    print('Days booked: ',length)
    print()
    if pay == 1:
        print('Paid by credit card')
    elif pay == 2:
        print('Paid by Cash')
    elif pay == 3:
        print('Paid by cheque')
    else:
        print('Error')

    print()

    if length == 1:
        print('The cost will be €', cost1, 'for', length, 'day.')
    elif length >= 2 and length <= 4:
        print('The cost will be €', cost2, 'for', length, 'days.')
    elif length >= 5 and length <= 8:
        print('The cost will be €', cost3, 'for', length, 'days.')
    elif length >= 9:
        print('The cost will be €', cost4, 'for', length, 'days.')
    else:
        print('Error')
elif press == 'CANCEL':
    print('')
else:
    print('Error')

#code for the openfile
openTheFile = open(bandname + ".txt", "a")
openTheFile.write('Booking Application' + "\n")
openTheFile.write('Requisition by: ' + name + Sname + ' Contact: ' + 'Email-' + email + '&' + 'Tel-' + num + "\n")
openTheFile.write("\n")
openTheFile.write('Band name is:' + bandname + "\n")
openTheFile.write("\n")
openTheFile.write('Date requested --->' + day + '/' + month + '/' + year + "\n")
openTheFile.write("\n")
openTheFile.write('Band Members' + "\n")
openTheFile.write('-------------------------------' + "\n")
openTheFile.write('1:' + musician1 + '-' + instrument1 + "\n")
openTheFile.write('2:' + musician2 + '-' + instrument2 + "\n")
openTheFile.write('3:' + musician3 + '-' + instrument3 + "\n")
openTheFile.write('4:' + musician4 + '-' + instrument4 + "\n")
openTheFile.write('5:' + musician5 + '-' + instrument5 + "\n")
openTheFile.write('6:' + musician6 + '-' + instrument6 + "\n")
openTheFile.write('7:' + musician7 + '-' + instrument7 + "\n")
openTheFile.write('8:' + musician8 + '-' + instrument8 + "\n")
openTheFile.write("\n")
openTheFile.write('Days booked: ' + str(length) + "\n")
openTheFile.write("\n")
if pay == 1:
    openTheFile.write('Paid by credit card' + "\n")
elif pay == 2:
    openTheFile.write('Paid by Cash' + "\n")
elif pay == 3:
    openTheFile.write('Paid by cheque' + "\n")
else:
    openTheFile.write('Error' + "\n")

print()

if length == 1:
    openTheFile.write('The cost will be €' + str(cost1) + ' for ' + str(length) + 'day.' + "\n")
elif length >= 2 and length <= 4:
    openTheFile.write('The cost will be €' + str(cost2) + ' for ' + str(length) + 'days.' + "\n")
elif length >= 5 and length <= 8:
    openTheFile.write('The cost will be €' + str(cost3) + ' for ' + str(length) + 'days.' + "\n")
elif length >= 9:
    openTheFile.write('The cost will be €' + str(cost4) + ' for ' + str(length) + 'days.' + "\n")
else:
    openTheFile.write('Error')

openTheFile.close()